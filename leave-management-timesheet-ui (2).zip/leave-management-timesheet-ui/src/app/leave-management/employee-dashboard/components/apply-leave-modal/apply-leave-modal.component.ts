import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-apply-leave-modal',
  templateUrl: './apply-leave-modal.component.html',
  styleUrls: ['./apply-leave-modal.component.css']
})
export class ApplyLeaveModalComponent implements OnInit {
  @Input() selectedDate: string|null=null;

  selectedEndDate: string|null=null;
  totalLeaveDays: number|null=null;
  returningWorkDate: string|null=null;
  halfDay: string|null=null;
  selectedLeaveTypeId: string|null=null;
  leaveTypes = [
    { id: '1', name: 'Sick Leave' },
    { id: '2', name: 'Casual Leave' },
    // Add more leave types as needed
  ];
  message: string|null=null;
  assignedToId: string|null=null;
  users = [
    { id: '1', first_name: 'John' },
    { id: '2', first_name: 'Jane' },
    // Add more users as needed
  ];

  constructor(public activeModal: NgbActiveModal) {}

  ngOnInit() {
    this.totalLeaveDays = this.calculateTotalLeaveDays();
    this.returningWorkDate = this.calculateReturningWorkDate();
  }

  getMinEndDate() {
    return this.selectedDate;
  }

  onEndDateChanged() {
    this.totalLeaveDays = this.calculateTotalLeaveDays();
    this.returningWorkDate = this.calculateReturningWorkDate();
  }

  calculateTotalLeaveDays() {
    if (!this.selectedDate || !this.selectedEndDate) {
      return 0;
    }
    const start = new Date(this.selectedDate);
    const end = new Date(this.selectedEndDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  }

  calculateReturningWorkDate() {
    if (!this.selectedEndDate) {
      return '';
    }
    const end = new Date(this.selectedEndDate);
    end.setDate(end.getDate() + 1);
    return end.toISOString().split('T')[0];
  }

  applyLeave() {
    const leaveData = {
      startDate: this.selectedDate,
      endDate: this.selectedEndDate,
      totalLeaveDays: this.totalLeaveDays,
      returningWorkDate: this.returningWorkDate,
      halfDay: this.halfDay,
      leaveType: this.selectedLeaveTypeId,
      message: this.message,
      assignedToId: this.assignedToId
    };

    // Replace this with your actual backend API call
    console.log('Leave data:', leaveData);

    this.activeModal.close();
  }
}
