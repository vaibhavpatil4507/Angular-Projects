import { Component } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interactionPlugin from '@fullcalendar/interaction';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApplyLeaveModalComponent } from '../apply-leave-modal/apply-leave-modal.component';

@Component({
  selector: 'app-calender',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent {
  calendarOptions: any;

  constructor(private modalService: NgbModal) {
    this.calendarOptions = {
      plugins: [dayGridPlugin, timeGridPlugin, listPlugin, interactionPlugin],
      initialView: 'dayGridMonth',
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
      },
      buttonText: {
        today: 'Today',
        month: 'Month',
        week: 'Week',
        day: 'Day',
        list: 'List'
      },
      dateClick: this.handleDateClick.bind(this),
      events: [
        { title: 'Event 1', date: '2024-06-01' },
        { title: 'Event 2', date: '2024-06-02' },
        { title: 'Long Event', start: '2024-06-07', end: '2024-06-10' }
      ],
      editable: true,
      droppable: true,
    };
  }

  handleDateClick(arg: any) {
    const modalRef = this.modalService.open(ApplyLeaveModalComponent);
    modalRef.componentInstance.selectedDate = arg.dateStr;
  }
}
