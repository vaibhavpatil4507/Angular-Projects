import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-timeoff',
  templateUrl: './employee-timeoff.component.html',
  styleUrl: './employee-timeoff.component.css'
})
export class EmployeeTimeoffComponent {

}
