import { Component, OnInit } from '@angular/core';
import { MasterService } from '../../../../components/services/master.service';
import { Employee } from '../employee/employee.component';
import { ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-employee-profile',
  templateUrl: './employee-profile.component.html',
  styleUrls: ['./employee-profile.component.css']
})
export class EmployeeProfileComponent implements OnInit {
  employee: any;

  constructor(
    private route: ActivatedRoute,
    private masterService: MasterService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const employeeId = Number(params.get('id'));
      if (employeeId) {
        this.masterService.getUserDetailsById(employeeId).subscribe((data: Employee) => {
          this.employee = data;
        });
      }
    });
  }
}