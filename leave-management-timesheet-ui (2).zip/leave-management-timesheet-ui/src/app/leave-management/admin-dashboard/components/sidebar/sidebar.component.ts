import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  user: any; // Property to store user details

  constructor(private router: Router) {}


  ngOnInit(): void {
    this.fetchUserDetails();
  }

  fetchUserDetails(): void {
    const storedUser = localStorage.getItem('userData');
    if (storedUser) {
      this.user = JSON.parse(storedUser);
    } else {
      console.error('User details not found in local storage');
    }
  }

  isManagePage():boolean {
    this.router.url === '/leave-management/admin-dashboard/manage'||this.router.url === '/leave-management/admin-dashboard/holiday'
      
        return true;
    
    // return this.router.url === '/leave-management/admin-dashboard/manage';
  }

  isEmployeeRelatedPage(): boolean {
    return (
      this.router.url === '/leave-management/admin-dashboard/employee' ||
      this.router.url ===
        '/leave-management/admin-dashboard/employee-profile' ||
      this.router.url === '/leave-management/admin-dashboard/employee-timeoff');
    }
}
