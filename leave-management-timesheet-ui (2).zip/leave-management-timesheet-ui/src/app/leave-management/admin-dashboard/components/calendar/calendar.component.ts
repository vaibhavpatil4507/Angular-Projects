import { Component, OnInit } from '@angular/core';
import { CalendarOptions } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { MasterService } from '../../../../components/services/master.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DateModalComponent } from './date-modal/date-modal.component';

@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.css']
})
export class CalendarComponent implements OnInit {
  calendarOptions: CalendarOptions = {};

  constructor(private masterService: MasterService, private modalService: NgbModal) { }

  ngOnInit(): void {
    this.initializeCalendarOptions();
    this.loadHolidays();
  }

  initializeCalendarOptions(): void {
    this.calendarOptions = {
      plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
      initialView: 'dayGridMonth',
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay',
      },
      height: 'auto',
      navLinks: true,
      events: [],
      dateClick: this.handleDateClick.bind(this),
      eventContent: (arg) => {
        return { html: `<div class="event-title">${arg.event.title}</div>` };
      }
    } as CalendarOptions;
  }

  loadHolidays(): void {
    this.masterService.getHolidays().subscribe(holidays => {
      const events = holidays.map(holiday => ({
        title: holiday.occasion,
        start: holiday.occasion_date
      }));
      this.calendarOptions.events = events;
    });
  }

  handleDateClick(arg: { dateStr: string }): void {
    const selectedDate = new Date(arg.dateStr); // Convert dateStr to Date object
    const modalRef = this.modalService.open(DateModalComponent);
    modalRef.componentInstance.selectedDate = selectedDate;
    modalRef.result.then((result) => {
      if (result) {
        // Handle result from modal if needed
        console.log('Modal closed with result:', result);
      }
    }, (reason) => {
      console.log('Dismissed', reason);
    });
  }
}
