export interface Holiday {
    title: string;
    start: Date; 
    // createdBy:number;
    // updateBy:number;
    // locationId:number;
    // isOptional:boolean;
  }