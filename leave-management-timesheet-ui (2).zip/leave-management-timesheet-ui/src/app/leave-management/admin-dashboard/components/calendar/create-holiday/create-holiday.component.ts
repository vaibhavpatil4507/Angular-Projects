import { Component } from '@angular/core';

@Component({
  selector: 'app-create-holiday',
  templateUrl: './create-holiday.component.html',
  styleUrl: './create-holiday.component.css'
})
export class CreateHolidayComponent {

}
